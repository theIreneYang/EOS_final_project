# EOS 簡易字幕投放螢幕

Windows 瀏覽器作為字幕螢幕，Pi 繼續負責 FCFS 排隊與離線辨識。
現有 `client_fcfs.py` 不需更動；不需新增 Python 套件，也不需外網。
這一階段為「完整 WAV 上傳 → 辨識完成 → 顯示整段字幕」，不是逐字串流字幕。

## 1. Windows 解壓縮並傳送

將 ZIP 內的 `server_fcfs_display.py`、`subtitles.html`、此說明檔直接解壓縮至：
`C:\桌面!!\EOS\EOS_final project`

Windows PowerShell：

```powershell
Set-Location 'C:\桌面!!\EOS\EOS_final project'
scp .\server_fcfs_display.py .\subtitles.html thelreneyang@192.168.222.222:~/EOS_Final_Project/
```

兩個檔案須放在 Pi 的同一個資料夾，並與 `.venv`、`models` 相鄰。
舊的 `server_fcfs.py` 保留。

## 2. Pi 啟動字幕版 Server

在原本 Server 的終端機按 Ctrl+C；等它處理完已接受的工作、回到命令提示字元後：

```bash
cd ~/EOS_Final_Project
.venv/bin/python server_fcfs_display.py
```

看到 `READY FCFS + DISPLAY` 後，Server 已可接收請求及顯示字幕。
Server 重啟後 sequence 從 1 開始，螢幕的字幕歷史重新開始；CSV 延續附加。

## 3. Windows 開啟字幕網址

在 Windows 的 Edge 或 Chrome 網址列輸入：

```
http://192.168.222.222:8000/display
```

這個位址是在 Windows 瀏覽器開啟，無法從 ChatGPT 的遠端瀏覽器直接存取實驗室 Pi。
不是雙擊 HTML 檔案開啟，因為字幕需從同一個 Server 的 `/api/state` 讀取。
畫面右上角應顯示「已連線 · 自動更新」。

## 4. 上傳 A / B 音檔

Windows PowerShell A：

```powershell
Set-Location 'C:\桌面!!\EOS\EOS_final project'
py -3 .\client_fcfs.py 'C:\Users\irene\Downloads\UncleRoger.wav' --client-id A
```

Windows PowerShell B：

```powershell
Set-Location 'C:\桌面!!\EOS\EOS_final project'
py -3 .\client_fcfs.py .\Client_B.wav --client-id B
```

先把指令都貼好，按 A Enter 後隨即切到 B 按 Enter。
辨識中會顯示目前的 Client 與排隊請求。
A 完成後主畫面出現 A 字幕；B 完成後顯示 B，A 留在「先前字幕」。
真正顯示的次序依完整上傳登記的先後而定，未保證字母 A 永遠優先。
瀏覽器以 0.5 秒輪詢一次；網路正常時，辨識完成後通常約一個輪詢間隔內更新。
輪詢與 HTTP 回覆可能因系統或網路負載增加耗時，並非固定延遲保證。

## 投放操作

- 「投放模式」：隱藏頁首、歷史與效能細節，保留主要字幕、目前狀態及操作按鈕。
- 「全螢幕」：請求瀏覽器全螢幕；Esc 可退出。也可按 F11。
- 「字幕大小」：28–84 px，設定保存在本機瀏覽器。小螢幕會限制字體大小避免橫向溢出。
- 同網段其他螢幕可開啟相同網址；各螢幕共用所有 Client 的完成結果。
- 不發出語音、不自動捲動、不自動清除最新字幕；新結果完成前保留上一筆。

## 紀錄與限制

FCFS 邏輯、單一辨識 worker、最大 8 筆進行中請求與原有 CSV 均保留。
API 為 `POST /transcribe`、`GET /health`、`GET /api/state`。
畫面狀態用獨立 Lock 同步；每次輪詢只讀快照，不占用辨識 worker。
螢幕 Server 以記憶體保留最近 30 筆完成請求（成功或失敗）；畫面顯示最新成功字幕及前 4 筆成功字幕。
CSV 位於 `~/EOS_Final_Project/logs/requests_fcfs.csv`，包含完整辨識文字。
失敗請求顯示提示；保留最後成功字幕。斷線顯示提示並自動重試，不把舊字幕當成新的。
新增瀏覽器只會同步已有結果，不會觸發重新辨識。
Server 重啟會更換 session ID，瀏覽器會自動重置舊字幕與序號。
延遲、等待與相對時間使用單調時鐘，不依賴 Pi 的日期是否校正。
只供可信任區域網路使用，沒有登入或 TLS，預設僅綁定 Pi 乙太網路位址。

## 排錯

- 網頁顯示 404：確認啟動的是 `server_fcfs_display.py`，而非舊 Server。
- FileNotFoundError: subtitles.html：確認 HTML 與字幕版 Python 放在 Pi 同一個資料夾。
- 連線中斷：檢查 Server 終端機與網路線；不需重新下載模型。
- 網頁只有舊版本：重新整理瀏覽器。
- 8000 埠已使用：先在舊 Server 終端機按 Ctrl+C，勿同時開兩份 Server。
- Server 只顯示準備好了：上傳新的 WAV。CSV 舊紀錄不會自動匯入字幕歷史。

## 驗證範圍

開發環境以替代辨識器驗證 HTTP、FIFO、字幕快照、錯誤與歷史上限。
畫面測試使用標示清楚的示範資料；真正 Pi 的 Vosk 與瀏覽器更新仍需實機驗證。
